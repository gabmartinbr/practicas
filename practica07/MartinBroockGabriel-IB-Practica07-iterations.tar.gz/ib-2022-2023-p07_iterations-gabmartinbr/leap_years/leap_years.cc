#include <iostream>
using namespace std;

int leap_years(int year) {
  if (year % 100 == 0) {
    if (year % 400 == 0)
      cout << "YES" << endl;
    else
      cout << "NO" << endl;
  } else if (year % 4 == 0)
    cout << "YES" << endl;
  else
    cout << "NO" << endl;
}

int main() {
  int year;
  cin >> year;
  leap_years(year);
  return 0;
}