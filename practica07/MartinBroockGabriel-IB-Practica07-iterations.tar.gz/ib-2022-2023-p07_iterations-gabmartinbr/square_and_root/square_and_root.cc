// Universidad de La Laguna
// Informática Básica
// @author Gabriel Martin Broock
// @brief print the square and square root of numbers
#include <iostream>
#include <math.h>
#include <iomanip>
using namespace std;

int square (); //funcion que calcula n elevado a 2
int root (); //funcion que calcula raíz cuadrada de n

int square (int input) {
  int square;
  square = input * input;
  return square;
}

double root (double input2) {
  double root;
  root = sqrt (input2);
  return root;
}

int main () {
  int input{0};
  cin >> input;
  double input2 = input;
  square (input);
  root (input2);
  cout << square (input) << " " << setprecision (7) << root (input2);

return 0;
}
