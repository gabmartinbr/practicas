// Universidad de La Laguna
// Informática Básica
// @author gabriel martin broock
// @brief programa que suma los dígitos del número introducido
#include <iostream>
#include <string.h>
#include <iomanip>
using namespace std;

int resultado (int serie_numerica) {
  int suma{0};
  int resultado{0};
  for (int i = 10; serie_numerica > 0; resultado >= 0) {
    suma = serie_numerica % i;
    serie_numerica = serie_numerica / i;
    resultado = resultado + suma;
  }
  return resultado;
  
}

int main () {
  int numero{0};
  cin >> numero;
  cout << resultado(numero) << endl;
  return 0;
}