// Universidad de La Laguna
// Informática Básica
// @author Gabriel Martin Broock
// @brief programa que dice si un numero es perfecto o no

#include <iostream>
using namespace std;

bool is_perfect ();

bool is_perfect (int n) {
  if (int input) {}
  
 




}


}





int main () {
  int input;
  while (cin >> input) {
  if (is_perfect(input)) {
    cout << "true";
   }
    else {
    cout << "false" << endl}

return 0;
}
}
