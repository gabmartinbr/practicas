#include <iostream>
using namespace std;

string mayus_a_minus (); // declarar la función

string mayus_a_minus (string cadena) {
  for (int i = 0; i < cadena.length(); i++) {
    if (cadena[i] == toupper(cadena[i])) {
      cadena[i] = tolower(cadena[i]);
    } else if (cadena[i] == tolower (cadena[i])) {
      cadena[i] = toupper (cadena[i]);
    }
  }
  return cadena;
}

int main () {
  string cadena;
  while (cin >> cadena) {
    string mayuscula = mayus_a_minus (cadena);
    cout << mayuscula << endl;
  }
  return 0;
}