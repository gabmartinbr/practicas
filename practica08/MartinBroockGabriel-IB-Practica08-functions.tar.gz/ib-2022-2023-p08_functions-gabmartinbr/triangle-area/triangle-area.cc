// Universidad de La Laguna
// Informática Básica
// @author Gabriel Martin Broock
// @brief calcula el area de un triangulo con la formula de Herón
#include <iostream>
#include <math.h>
using namespace std;

void IsAValidTriangle (); // funcion que determina si un triangulo es válido o no
float Area (); // funcion que calcula el area con los 3 lados introducidos

void IsAValidTriangle (float a, float b, float c) {
  if (a + b <= c || a + c <= b || b + c <= a) {
    cout << "not a valid triangle" << endl;
  }
}

float Area (float a, float b, float c) {
  float calc_area;
  float s;
  s = (a + b + c) / 2;
  calc_area = sqrt (s * (s - a) * (s -b) * (s - c));
  return calc_area;
}

int main () {
  float ladoA, ladoB, ladoC;
  cin >> ladoA >> ladoB >> ladoC;
  IsAValidTriangle (ladoA, ladoB, ladoC);
  cout << Area (ladoA, ladoB, ladoC) << endl;
  
  return 0;
}