// Universidad de La Laguna
// Informática Básica
// @author Gabriel Martin Broock
// @brief random number generator between 2 numbers
#include <iostream>
#include <experimental/random>
using namespace std;

int random_number (); // funcion que genera un numero aletorio de un intervalo

int random_number (int a, int b) {
  int number;
  number = std::experimental::randint (a, b);
  return number;
}

int main () {
  int num1, num2;
  cin >> num1 >> num2;
  cout << random_number (num1, num2) << endl;

  return 0;
}