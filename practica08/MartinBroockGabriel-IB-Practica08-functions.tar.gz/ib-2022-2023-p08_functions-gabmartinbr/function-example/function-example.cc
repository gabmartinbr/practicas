// Universidad de La Laguna
// Informática Básica
// @author Gabriel Martin Broock
#include <iostream>
#include <math.h>
using namespace std;

double function_example (); // funcion que calcula  calcula la opercion del enunciado

double function_example (double x, double y, double t) {
  double g{0};
  g = (sqrt((2 * t) - 4) / ((x * x) - (y * y)));
  return g;
}

int main () {
  double num1, num2, num3;
  cin >> num1 >> num2 >> num3;
  cout << function_example (num1, num2, num3) << endl;
  return 0;
}