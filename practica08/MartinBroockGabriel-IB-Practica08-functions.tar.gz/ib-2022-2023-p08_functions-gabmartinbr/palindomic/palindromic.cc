#include <iostream>
#include <string.h>

using namespace std;

bool is_palindromic (int n) {
  stringstream number;
  number << n;
  bool bo = 1;
  for (int i = 0; i < number.size(); i++) {
    bo = bo && (numero[i] == n[number.size() -i -1]);
  } return bo;;

}

int main () {
  int input;
  while (cin >> input){
  if (is_palindromic(input)){
   cout << "true" << endl;
  } 
  else {
cout << "false" << endl;
}

}
return 0;
}
