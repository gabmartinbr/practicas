#include <iostream>
using namespace std;

int main () {
    char letra;
    cin >> letra;
    if (letra < 'a') {
      cout << (char)(letra+('a'-'A')) << endl;
    }
    else {
      cout << (char)(letra+('A'-'a')) << endl;
    }
}