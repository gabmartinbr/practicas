// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Informática Básica
// @author Gabriel Martin Broock
// @brief Write a program that adds one second to a clock time, given its hours, minutes and seconds.
#include <iostream>
#include <iomanip>
using namespace std;

int main () {
  int hh, mm, ss;
  cin >> hh >> mm >> ss;
  ss++;
  if (ss == 60) {
    mm++; 
    ss = 0;
  }
  if (mm == 60) {
    hh++;
    mm = 0;
    ss = 0;
  }
  if (hh == 24) {
    hh = 0;
    mm = 0;
    ss = 0;
  }
  cout << setfill('0') << setw(2) << hh << ':';
  cout << setfill('0') << setw(2) << mm << ':';
  cout << setfill('0') << setw(2) << ss << endl;
  return 0;
};