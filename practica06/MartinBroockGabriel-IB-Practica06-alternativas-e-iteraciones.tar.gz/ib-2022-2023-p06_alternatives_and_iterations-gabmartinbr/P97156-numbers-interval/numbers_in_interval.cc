// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Informática Básica
// @author Gabriel Martin Broock
// @brief Write a program that reads two numbers a and b, and prints all numbers
// between a and b.
#include <iostream>
using namespace std;

int main() {
  int num1{0};
  int num2{0};
  cin >> num1 >> num2;

  for (int i = num1; i < num2; i++) {
    cout << i << ',';
  }
  if (num1 <= num2) {
    cout << num2;
  }
  cout << endl;
  return 0;
}