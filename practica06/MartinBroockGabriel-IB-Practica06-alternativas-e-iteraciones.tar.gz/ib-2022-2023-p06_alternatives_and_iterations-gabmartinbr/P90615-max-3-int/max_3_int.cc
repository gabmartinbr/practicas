// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Informática Básica
// @author Gabriel Martin Broock
// @brief Outputs the maximum of 3 integers given by the user

#include <iostream>
using namespace std;

int main() {
  int number1, number2, number3;
  int maximum;
  cin >> number1 >> number2 >> number3;
  if (number1 >= number2 && number1 >= number3) {
    maximum = number1;
  } else if (number2 >= number3 && number2 >= number1 ) {
    maximum = number2;
  } else {
    maximum = number3;
  }
  cout << maximum << endl;

  return 0;
}