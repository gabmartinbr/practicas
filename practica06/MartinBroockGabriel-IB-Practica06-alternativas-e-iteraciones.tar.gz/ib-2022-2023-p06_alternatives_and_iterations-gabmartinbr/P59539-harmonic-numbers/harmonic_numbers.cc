// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Informática Básica
// @author Gabriel Martin Broock
// @brief Write a program that reads a number n and prints the n-th harmonic
// number, defined as Hn = 1/1 + 1/2 + ⋯ + 1/n.
#include <iomanip>
#include <iostream>
using namespace std;

int main() {
  int denominador{0};
  double harmonic{0.0};
  cin >> denominador;
  for (double i = 1; i <= denominador; i++) {
    harmonic += 1.0 / i;
  }
  cout << fixed << setprecision(4) << harmonic << endl;
  return 0;
}