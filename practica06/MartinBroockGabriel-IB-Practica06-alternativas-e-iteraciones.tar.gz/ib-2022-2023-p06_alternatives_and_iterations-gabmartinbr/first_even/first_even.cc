// Universidad de La Laguna
// Informática Básica
// @author gabriel martin broock
// @brief Write a program that reads a sequence of natural numbers and prints the position of the first even number.
#include <iostream>
#include <string>

int main () {
  std::string sequence = " ";
  int number_test, numbers;
  int iterations{1};
  std::cin >> sequence;
  numbers = stoi(sequence);
  for (int i = 10; numbers > 0; iterations++)  {
    number_test = numbers % 10;
    numbers = numbers / 10;

   if (number_test % 2 == 0) {
      std::cout << iterations;
    }
    }

  return 0;
}
