#include "triangle.h"
#include <algorithm>
#include <array>
#include <stdexcept>
using namespace std;
using namespace triangle;

namespace triangle {
  flavor kind(double lado1, double lado2, double lado3) {
    array<double, 3> lados{ lado1, lado2, lado3 };
    sort(lados.begin(), lados.end());

    if (lados[0] <= 0) { //lados > 0
      throw domain_error("Todos los lados deben ser mayores que 0");
    }

    if (lados[0] + lados[1] < lados[2]) { // lados validos
      throw domain_error("No es un triángulo válido");
    }
    // tipo de triangulo
    if (lados[0] == lados[2]) {
      return flavor::equilateral;
    }
    if (lados[0] == lados[1] || lados[1] == lados[2]) {
      return flavor::isosceles;
    } else {
      return flavor::scalene;
    }
    
  }

}  // namespace triangle
