#if !defined(TRIANGLE_H)
#define TRIANGLE_H

namespace triangle {
  enum class flavor {
    equilateral, 
    isosceles,
    scalene
  };

  flavor kind(double lado1, double lado2, double lado3);
}  // namespace triangle

#endif // TRIANGLE_H