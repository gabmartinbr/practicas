// Universidad de La Laguna
// @author Gabriel Martin Broock
// @brief implments a funtion that returns largest prime factor of user's input

#include <iostream>
using namespace std;

int largest_prime_factor(int n); //function that returns largest prime factor

int largest_prime_factor(int n) {
  int counter = 0;
  
  for (int i = n; i >= 2 ; --i ) {

    for (int m = 2; m<i; ++m) {
      if (n % m == 0) {
        ++counter;
      }
  }
  
  if (counter == 0) {
  return i;
  break;
  }
  counter = 0;
} 
return 0;
}



int main() {
  int number = 0;
  while (cin >> number) {
  cout << largest_prime_factor(number) << endl;
}
return 0;
}
