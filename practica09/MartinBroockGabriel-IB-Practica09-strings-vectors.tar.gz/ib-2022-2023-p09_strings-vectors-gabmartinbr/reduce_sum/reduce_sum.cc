#include <iostream>
#include <vector>
using namespace std;


vector <float> ReduceSum (int size, vector <float> input) {

}


int main () {


  return 0;
}