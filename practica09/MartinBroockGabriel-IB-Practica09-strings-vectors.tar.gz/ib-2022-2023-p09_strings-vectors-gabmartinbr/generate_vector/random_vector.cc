#include <iostream>
#include <vector>
#include <cstdlib>
#include "generate_vector.h"

int main (char* argv[]) {
  int size{std::stoi(argv[1])};
  double lower_number{std::stod(argv[1])};
  double upper_number{std::stod(argv[2])};
  std::vector<double> random_vector{GenerateVector(size, lower_number, upper_number)};
  int index = 0;
  for (const auto& component : random_vector) {
    std::cout << "Component " << index << ": " << component << std::endl;
    ++index;
  }

  return 0;
}

