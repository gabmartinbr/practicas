#include <iostream>
#include <vector>
#include <cstdlib>
#include <iomanip>
#include <ctime>
#include "generate_vector.h"
using namespace std;

vector <double> GenerateVector (const  int size, double lower, double upper) {
  srand(time(NULL));
  vector <double> my_vector(size);
  cout << "Vector: " << endl;
  for (int i = 0; i < size; i++) {
    my_vector[i] = (rand() / (double)RAND_MAX) * (upper - lower) + lower;
    cout << fixed << setprecision(2) << my_vector[i] << " ";
  }
  return my_vector;

}
