#include <iostream>
#include <vector>
#include <cstdlib>
using namespace std;

double random_number (const double lower, const double upper) {
  double random = static_cast <double> (rand()) / RAND_MAX;
  return lower + random * (upper - lower);
}

vector <double> GenerateVector (const  int size, double lower, double upper) {
  vector <double> generate_vector;
  generate_vector.resize(size);
  for (int index = 0; index < size; ++index) {
    generate_vector[index] = random_number (lower, upper);
    return generate_vector;
  }
}

int main (int argc, char* argv[]) {
  int size{std::stoi(argv[1])};
  double lower_number{std::stod(argv[2])};
  double upper_number{std::stod(argv[3])};
  vector <double> random_vector{GenerateVector (size, lower_number, upper_number)};
  int index = 0;
  for (const auto& component : random_vector) {
    cout << "Component " << index << ": " << component << endl;
    ++index;
  }
  return 0;

}