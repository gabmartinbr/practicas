#include <iostream>
#include <vector>
#include <cstdlib>
#include <iomanip>
#include <ctime>

std::vector<double> GenerateVector(const double size, const double lower, const double upper);