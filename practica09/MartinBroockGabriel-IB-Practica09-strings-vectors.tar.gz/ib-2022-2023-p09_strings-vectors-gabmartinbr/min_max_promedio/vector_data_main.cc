#include <iostream>
#include <vector>
#include <numeric>
#include <algorithm>
#include "vector_data.h"

int main(int argc, char *argv[]) {
  double size = atof(argv[1]);
  double lower = atof(argv[2]);
  double upper = atof(argv[3]);

  VectorData(GenerateVector(size, lower, upper));
  
}