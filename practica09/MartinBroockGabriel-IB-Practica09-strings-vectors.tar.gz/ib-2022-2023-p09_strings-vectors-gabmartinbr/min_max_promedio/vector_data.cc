#include <iostream>
#include <vector>
#include <numeric>
#include <algorithm>
#include "vector_data.h"

void Vectordata(std::vector<double> my_vector) {
  std::cout << "\n" << "Average = " << (std::accumulate(my_vector.begin(), my_vector.end(), 0.00)) / my_vector.size() << std::endl;
  std::cout << "Maximum = " << *max_element(my_vector.begin(), my_vector.end()) << std::endl;
  std::cout << "Minimum = " <<*min_element(my_vector.begin(), my_vector.end());
}