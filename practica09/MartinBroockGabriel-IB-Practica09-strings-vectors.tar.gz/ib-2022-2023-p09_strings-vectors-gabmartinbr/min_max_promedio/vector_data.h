#include <iostream>

void VectorData(std::vector<double> my_vector);